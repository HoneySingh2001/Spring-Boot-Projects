package Telecom.SubscriptionService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import Telecom.SubscriptionService.dto.AccountDto;
import Telecom.SubscriptionService.dto.ResponseMessage;
import Telecom.SubscriptionService.model.Account;
import Telecom.SubscriptionService.service.AccountService;

@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	AccountService service;
	
	@GetMapping("")
	@ResponseStatus(HttpStatus.OK)
	public List<Account> getAllAccounts(){
		return service.getAll();
	}
	
	@GetMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Account getAccountById(@PathVariable Long id) {
		return service.findById(id);
	}
	
	@GetMapping("/userId/{userId}")
	@ResponseStatus(HttpStatus.OK)
	public Account getAccountByUserId(@PathVariable Long userId) {
		return service.findByUserId(userId);
	}
	
	@PutMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Account updateAccountById(@PathVariable Long id, @RequestBody AccountDto accountDto) {
		return service.updateById(id,accountDto);

	}
	
	@PostMapping("")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseMessage saveAccount(@RequestBody AccountDto accountDto) {
		return service.saveAccount(accountDto);
	}
	
	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseMessage deleteById(@PathVariable Long id) {
		return service.delete(id);
	}
}

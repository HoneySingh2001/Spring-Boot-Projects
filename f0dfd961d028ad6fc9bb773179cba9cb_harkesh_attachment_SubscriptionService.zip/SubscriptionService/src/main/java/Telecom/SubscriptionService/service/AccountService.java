package Telecom.SubscriptionService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Telecom.SubscriptionService.dto.AccountDto;
import Telecom.SubscriptionService.dto.ResponseMessage;
import Telecom.SubscriptionService.model.Account;
import Telecom.SubscriptionService.model.User;
import Telecom.SubscriptionService.repository.AccountRepository;
import Telecom.SubscriptionService.repository.UserRepository;

@Service
public class AccountService {

	@Autowired
	AccountRepository accountRepo;
	
	@Autowired
	UserRepository userRepo;
	
	public List<Account> getAll() {
		return accountRepo.findAll();
	}


	public Account findById(Long id) {
//		return accountRepo.findById(id).get();
		return accountRepo.findById(id).orElse(null);
	}


	public Account findByUserId(Long userId) {
		User user = userRepo.findById(userId).get();
		if(user!=null) {
			return user.getAccount();
		}
		else
			throw new RuntimeException("User for this id does not exist");
	}


	public Account updateById(Long id, AccountDto accountDto) {
		Account account = accountRepo.findById(id).orElse(null); // removed .get()
		if(account!=null) {
			account.setBalance(accountDto.getBalance());
			account.setDetails(accountDto.getDetails());
			account.setUser(accountDto.getUser());
			return accountRepo.save(account);
		}
		else
			throw new RuntimeException("Account for this id does not exist");
		
	}


	public ResponseMessage saveAccount(AccountDto accountDto) {
		Account account = new Account();
		account.setBalance(accountDto.getBalance());
		account.setDetails(accountDto.getDetails());
		account.setUser(accountDto.getUser());
		accountRepo.save(account);
		ResponseMessage response = new ResponseMessage();
		response.setMessage("Account Created Successfully");
		return response;
	}


	public ResponseMessage delete(Long id) {
		Account account = accountRepo.findById(id).get();
		if(account!=null) {
			accountRepo.deleteById(id);
			ResponseMessage response = new ResponseMessage();
			response.setMessage("Account Successfully Deleted");
			return response;
		}
		else
			throw new RuntimeException("Account for this id does not exist");
		
	}

}

package Telecom.SubscriptionService.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import Telecom.SubscriptionService.BillingDtos.InvoiceDto;
import Telecom.SubscriptionService.dto.ResponseMessage;
import Telecom.SubscriptionService.dto.SubscriptionDto;
import Telecom.SubscriptionService.model.Subscription;
import Telecom.SubscriptionService.model.User;
import Telecom.SubscriptionService.repository.SubscriptionRepository;
import Telecom.SubscriptionService.repository.UserRepository;

@Service
public class SubscriptionService {

	@Autowired
	SubscriptionRepository repo;
	@Autowired
	UserRepository userRepo;
	@Autowired
	UserService userService;


	private  final RestTemplate restTemplate;

	public SubscriptionService(RestTemplateBuilder builder) {
		this.restTemplate = builder.build();
	}

//	public  SubscriptionService(RestTemplate restTemplate) {
//		this.restTemplate = restTemplate;
//	}
	public List<Subscription> getAllSubscription() {
		return repo.findAll();
	}
	public Subscription getById(Long id) {
		return repo.findById(id).get();
	}
	public List<Subscription> getSubscriptionByUserId(Long userId) {
		User user = userRepo.findById(userId).orElse(null);
		if(user!=null) {
			return user.getSubscription();
		}
		else
			throw new RuntimeException("User for this id does not exist");
	}
	// return type should be void instead of string
	public void updateSubscription(Long id, SubscriptionDto subscriptionDto) {
		Subscription subscription=repo.findById(id).orElse(null);
		if(subscription!=null) {
			// this if-condition is necessary. because userId might be null
			if (subscriptionDto.getUserId() != null) {
				subscription.setUser(userRepo.findById(subscriptionDto.getUserId()).get());
			}
			subscription.setPlanDetails(subscriptionDto.getPlanDetails());
			subscription.setPlanName(subscriptionDto.getPlanName());
			subscription.setPrice(subscriptionDto.getPrice());
			repo.save(subscription);
//			return "Subscription updated successfully";
			
		}
		else {
			throw new RuntimeException("Subscription for this id does not exist");
		}
	}
	public ResponseMessage createSubscription(SubscriptionDto subscriptionDto) {
		Subscription subscription = new Subscription();
		subscription.setPlanDetails(subscriptionDto.getPlanDetails());
		subscription.setPlanName(subscriptionDto.getPlanName());
		subscription.setPrice(subscriptionDto.getPrice());
		subscription.setUser(userService.findById(subscriptionDto.getUserId()));
		repo.save(subscription);
		
		InvoiceDto invoiceDto = new InvoiceDto();
		invoiceDto.setAmount(subscriptionDto.getPrice());
		invoiceDto.setCustomerName(subscriptionDto.getPlanName());
		invoiceDto.setInvoiceDate(new Date().toString());
		invoiceDto.setSubscriptionId(subscriptionDto.getUserId());
		
		String url = "http://localhost:8082/Invoice";
		ResponseMessage message = restTemplate.postForEntity(url, invoiceDto, ResponseMessage.class).getBody();
		
		
		
		ResponseMessage response=new ResponseMessage();
		response.setMessage("Subscription Created Successfully");
		return response;
		
	}
	public ResponseMessage deleteSubscriptionById(Long id) {
		Subscription subscription = repo.findById(id).orElse(null);
		if(subscription!=null) {
			repo.deleteById(id);
			ResponseMessage response=new ResponseMessage();
			response.setMessage("Subscription Deleted Successfully");
			return response;
		}
		else {
			throw new RuntimeException("Subscription for this id does not exist");
		}
	}

}

package Telecom.SubscriptionService.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Telecom.SubscriptionService.dto.ResponseMessage;
import Telecom.SubscriptionService.dto.SubscriptionDto;
import Telecom.SubscriptionService.model.Subscription;
import Telecom.SubscriptionService.model.User;
import Telecom.SubscriptionService.repository.SubscriptionRepository;
import Telecom.SubscriptionService.repository.UserRepository;

@Service
public class SubscriptionService {

	@Autowired
	SubscriptionRepository repo;
	@Autowired
	UserRepository userRepo;
	@Autowired
	UserService userService;
	
	public List<Subscription> getAllSubscription() {
		return repo.findAll();
	}
	public Subscription getById(Long id) {
//		return repo.findById(id).get();
		return repo.findById(id)
			.orElseThrow(() -> new NoSuchElementException("Subscription not found with ID: " + id));
	}
	public List<Subscription> getSubscriptionByUserId(Long userId) {
		User user = userRepo.findById(userId).orElse(null);
		if(user!=null) {
			return user.getSubscription();
		}
		else
			throw new RuntimeException("User for this id does not exist");
	}
	// return type should be void instead of string
	public void updateSubscription(Long id, SubscriptionDto subscriptionDto) {
		Subscription subscription=repo.findById(id).orElse(null);
		if(subscription!=null) {
			// this if-condition is necessary. because userId might be null
			if (subscriptionDto.getUserId() != null) {
				subscription.setUser(userRepo.findById(subscriptionDto.getUserId()).get());
			}
			subscription.setPlanDetails(subscriptionDto.getPlanDetails());
			subscription.setPlanName(subscriptionDto.getPlanName());
			subscription.setPrice(subscriptionDto.getPrice());
			repo.save(subscription);
//			return "Subscription updated successfully";
			
		}
		else {
			throw new RuntimeException("Subscription for this id does not exist");
		}
	}
	public ResponseMessage createSubscription(SubscriptionDto subscriptionDto) {
		Subscription subscription = new Subscription();
		subscription.setPlanDetails(subscriptionDto.getPlanDetails());
		subscription.setPlanName(subscriptionDto.getPlanName());
		subscription.setPrice(subscriptionDto.getPrice());
		subscription.setUser(userService.findById(subscriptionDto.getUserId()));
		repo.save(subscription);
		ResponseMessage response=new ResponseMessage();
		response.setMessage("Subscription Created Successfully");
		return response;
		
	}
	public ResponseMessage deleteSubscriptionById(Long id) {
		Subscription subscription = repo.findById(id).orElse(null);
		if(subscription!=null) {
			repo.deleteById(id);
			ResponseMessage response=new ResponseMessage();
			response.setMessage("Subscription Deleted Successfully");
			return response;
		}
		else {
			throw new RuntimeException("Subscription for this id does not exist");
		}
	}

}

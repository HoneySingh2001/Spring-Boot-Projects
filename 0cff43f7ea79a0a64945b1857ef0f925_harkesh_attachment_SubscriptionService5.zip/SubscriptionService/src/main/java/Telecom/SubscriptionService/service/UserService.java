package Telecom.SubscriptionService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Telecom.SubscriptionService.dto.ResponseMessage;
import Telecom.SubscriptionService.dto.UserDto;
import Telecom.SubscriptionService.model.Subscription;
import Telecom.SubscriptionService.model.User;
import Telecom.SubscriptionService.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepo;
	
	public List<User> getAll() {
//	     if(userRepo.findAll()!=null)
	    	 return userRepo.findAll();
//	     else
//	    	 throw new RuntimeException("No User is found");
	}

	public User findById(Long id) {
		return userRepo.findById(id).orElse(null);
	}

	public User findByname(String name) {
		return userRepo.findByName(name);
	}

	public User getByEmail(String email) {
		return userRepo.findByEmail(email);
	}

	public ResponseMessage saveUser(UserDto userDto) {
		User user = new User();
		user.setAccount(userDto.getAccount());
		user.setAddress(userDto.getAddress());
		user.setContact(userDto.getContact());
		user.setEmail(userDto.getEmail());
		user.setName(userDto.getName());

		List<Subscription> list = userDto.getSubscriptionList();
		if(list!=null) {
			user.setSubscription(list);
		}
		for(Subscription subscription : userDto.getSubscriptionList()){
			subscription.setUser(user);
		}
		userRepo.save(user); // added this line
		ResponseMessage response = new ResponseMessage();
		response.setMessage("User created Successfully");

		return response;
	}

	public ResponseMessage delete(Long id) {
		if(userRepo.findById(id).orElse(null)!=null) {
			userRepo.deleteById(id);
			ResponseMessage response = new ResponseMessage();
			response.setMessage("User Deleted Successfully");
			return response;
		}
		else
			throw new RuntimeException("User not found");
	}

	public ResponseMessage updateById(Long id, UserDto userDto) {
		User user = userRepo.findById(id).get();
		if(user!=null) {
			
			user.setAccount(userDto.getAccount());
			user.setAddress(userDto.getAddress());
			user.setContact(userDto.getContact());
			user.setEmail(userDto.getEmail());
			user.setName(userDto.getName());
//			List<Subscription> list = userDto.getSubscriptionList();
//			if(list!=null) {
//				user.setSubscription(list);
//			}

			// added this code to create foreign key inside subscription table
			for(Subscription subscription : userDto.getSubscriptionList()){
				subscription.setUser(user);
			}


			user.setSubscription(userDto.getSubscriptionList());
			userRepo.save(user);
			ResponseMessage response = new ResponseMessage();
			response.setMessage("User updated Successfully");
			return response;
			
		}
		else
			throw new RuntimeException("User not found");
	}

}

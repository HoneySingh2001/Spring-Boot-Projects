package Telecom.SubscriptionService.dto;

import Telecom.SubscriptionService.model.User;

import lombok.Data;
@Data
public class AccountDto {

	private User user;
	private String balance;
	private String details;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
}

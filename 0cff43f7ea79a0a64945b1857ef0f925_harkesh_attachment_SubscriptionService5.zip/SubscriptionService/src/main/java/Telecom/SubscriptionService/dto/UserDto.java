package Telecom.SubscriptionService.dto;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import Telecom.SubscriptionService.model.Account;
import Telecom.SubscriptionService.model.Subscription;
import lombok.Data;

@Data
public class UserDto {

	private String name;
	private String email;
	private BigInteger contact;
	private String address;
	private Account account;
	private List<Subscription> subscriptionList=new ArrayList<>();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public BigInteger getContact() {
		return contact;
	}
	public void setContact(BigInteger contact) {
		this.contact = contact;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public List<Subscription> getSubscriptionList() {
		return subscriptionList;
	}
	public void setSubscriptionList(List<Subscription> subscriptionList) {
		this.subscriptionList = subscriptionList;
	}
	
}


package Telecom.SubscriptionService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import Telecom.SubscriptionService.dto.ResponseMessage;
import Telecom.SubscriptionService.dto.SubscriptionDto;
import Telecom.SubscriptionService.model.Subscription;
import Telecom.SubscriptionService.service.SubscriptionService;

@RestController
@RequestMapping("/api")
public class SubscriptionController {

	@Autowired
	SubscriptionService service;
	
	@GetMapping("/subscription")
	@ResponseStatus(HttpStatus.OK)
	public List<Subscription> getAllSubscription(){
		return service.getAllSubscription();
	}
	
	@GetMapping("/subscription/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Subscription getById(@PathVariable Long id) {
		return service.getById(id);
	}
	
	@GetMapping("/subscription/userId/{userId}")
	@ResponseStatus(HttpStatus.OK)
	public List<Subscription> getSubscriptionByUserId(@PathVariable Long userId){
		return service.getSubscriptionByUserId(userId);
	}
	
	@PutMapping("/subscription/{id}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseMessage updateSubscription(@PathVariable Long id, @RequestBody SubscriptionDto subscriptionDto) {
		 service.updateSubscription(id,subscriptionDto);
		return new ResponseMessage("Subscription Updated Successfully");
	}
	
	@PostMapping("/subscription")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseMessage createSubscription(@RequestBody SubscriptionDto subscriptionDto) {
		return service.createSubscription(subscriptionDto);
	}
	
	@DeleteMapping("/subscription/{id}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseMessage deleteSubscriptionById(@PathVariable Long id) {
		return service.deleteSubscriptionById(id);
	}
	
}

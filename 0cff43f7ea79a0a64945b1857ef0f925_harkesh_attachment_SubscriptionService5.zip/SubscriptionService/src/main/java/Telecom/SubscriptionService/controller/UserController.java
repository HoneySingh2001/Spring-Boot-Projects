package Telecom.SubscriptionService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import Telecom.SubscriptionService.dto.ResponseMessage;
import Telecom.SubscriptionService.dto.UserDto;
import Telecom.SubscriptionService.model.User;
import Telecom.SubscriptionService.service.UserService;

@RestController
@RequestMapping("/api/user")
public class UserController {

	@Autowired
	UserService service;
	
	@GetMapping("")
	@ResponseStatus(HttpStatus.OK)
	public List<User> getAllUsers(){
		return service.getAll();
	}
	
	@GetMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public User getUserById(@PathVariable Long id) {
		return service.findById(id);
	}
	
	@GetMapping("/name/{name}")
	@ResponseStatus(HttpStatus.OK)
	public User getAccountByUserId(@PathVariable String name) {
		return service.findByname(name);
	}
	
	@GetMapping("/email/{email}")
	@ResponseStatus(HttpStatus.OK)
	public User getByemail(@PathVariable String email) {
		return service.getByEmail(email);
	}
	
	@PostMapping("")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseMessage saveUser(@RequestBody UserDto userDto) {
		return service.saveUser(userDto);
	}
	
	@PutMapping("/{id}")
	public ResponseMessage updateById(@PathVariable Long id, @RequestBody UserDto userDto) {
		return service.updateById(id,userDto);
	}
	
	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseMessage deleteById(@PathVariable Long id) {
		return service.delete(id);
	}
}

package net.javaguides.springboot.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	
	@PostMapping("/signin")
    @ResponseBody
    public String signIn(@RequestParam String username, @RequestParam String password) {
        // Basic authentication logic (for demonstration)
        if ("exampleUser".equals(username) && "examplePassword".equals(password)) {
            return "success"; // Return some response indicating successful sign-in
        } else {
            return "failure"; // Return some response indicating failed sign-in
        }
    }
	
	@GetMapping("/")
	public String home() {
		return "index";
	}
}

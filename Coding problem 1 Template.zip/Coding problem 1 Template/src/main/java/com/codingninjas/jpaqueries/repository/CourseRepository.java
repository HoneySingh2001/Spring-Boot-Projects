package com.codingninjas.jpaqueries.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codingninjas.jpaqueries.entities.Course;
import com.codingninjas.jpaqueries.entities.Student;

public interface CourseRepository extends JpaRepository<Course, Integer> {

	Optional<Course> findByName(String course);
	

}

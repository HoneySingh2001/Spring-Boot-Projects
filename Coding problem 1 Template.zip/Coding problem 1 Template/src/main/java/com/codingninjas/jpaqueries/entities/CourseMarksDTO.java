package com.codingninjas.jpaqueries.entities;

public class CourseMarksDTO {
	private String course;

	private double marks;

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}
}

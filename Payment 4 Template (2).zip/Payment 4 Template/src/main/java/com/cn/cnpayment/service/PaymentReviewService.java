package com.cn.cnpayment.service;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cn.cnpayment.dal.PaymentReviewDAL;
import com.cn.cnpayment.entity.PaymentReview;
import java.util.List;

@Service
public class PaymentReviewService {

// Autowire the PaymentReviewDAL object.
	@Autowired
	PaymentReviewDAL paymentReviewDAL;

	@Transactional
	public PaymentReview getPaymentReviewById(int id) {
		/**
		   1. This method fetches PaymentReview for a specific id.
		   2. If no paymentReview is found then it throws NotFoundException.
		**/
		return paymentReviewDAL.getById(id);
	}

	@Transactional
	public List<PaymentReview> getAllPaymentReviews() {
		return paymentReviewDAL.getAllPaymentReview();
	}

	@Transactional
	public void savePaymentReview(PaymentReview newPaymentReview) {
		 paymentReviewDAL.save(newPaymentReview);
	}

	@Transactional
	public void delete(int id) {
		paymentReviewDAL.delete(id);
	}

	@Transactional
	public List<PaymentReview> getPaymentReviewByQueryType(String queryType){
		return paymentReviewDAL.getByQueryType(queryType);
	}

}

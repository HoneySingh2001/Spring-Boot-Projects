package com.cn.cnpayment.dal;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cn.cnpayment.entity.PaymentDetails;
import com.cn.cnpayment.entity.PaymentReview;
import com.cn.cnpayment.exception.NotFoundException;

import jakarta.persistence.EntityManager;



@Repository
public class PaymentReviewDALImpl implements PaymentReviewDAL {

	@Autowired
	EntityManager entityManager;
	@Override
	public PaymentReview getById(int id) {
		Session session=entityManager.unwrap(Session.class);
		PaymentReview paymentReview=session.get(PaymentReview.class, session);
		return paymentReview;
	}

	@Override
	public void save(PaymentReview paymentDetails) {
		Session session=entityManager.unwrap(Session.class);
		session.save(paymentDetails);
		
	}

	@Override
	public void delete(int id) {
		Session session=entityManager.unwrap(Session.class);
		PaymentReview paymentReview=session.get(PaymentReview.class,session);
		session.delete(paymentReview);
		
		
	}

	@Override
	public List<PaymentReview> getAllPaymentReview() {
		Session session=entityManager.unwrap(Session.class);
		List<PaymentReview> paymentReviewList=session.createQuery(
				"SELECT p FROM PaymentReview p", PaymentReview.class).getResultList();
		return paymentReviewList;
	}

	@Override
	public List<PaymentReview> getByQueryType(String queryType) {
		List<PaymentReview> paymentReviewList=getAllPaymentReview();
		List<PaymentReview> paymentReviewListByqueryType=new ArrayList<>();
		
		for(PaymentReview paymentReview:paymentReviewList) {
			if(paymentReview.queryType.equals(queryType)) {
				paymentReviewListByqueryType.add(paymentReview);
			}
			else {
				throw new NotFoundException("PaymentReview with this quryType is not Found");
			}
		}
		return paymentReviewListByqueryType;
	}

/**

 Complete the PaymentReviewDALImpl implementation class as mentioned below:

 	a. Autowire EntityManager.

 	b. Override the following methods:

 		1. getById(int id): This method fetches PaymentReview for a specific id.

 		2. getAllPaymentReview(): This method fetches the list of all PaymentReview from the database.

 		3. save(PaymentReview paymentReview): This method saves the PaymentReview entity into the database.

 		4. delete(int id): This method deletes the PaymentReview entity from the database for a specific id.

 		5. getByQueryType(String queryType): This method fetches the list of PaymentReview based on the
                                             queryType received.

 **/

}

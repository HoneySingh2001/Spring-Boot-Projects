package com.example.todocrud.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.todocrud.entity.Users;
import com.example.todocrud.repository.UserRepository;

@Service
public class UserServices {
    @Autowired
    UserRepository userRepository;

    public Users getUserById (Long userId){
       return userRepository.findById(userId).get();
    }

    public Users addUser(Users user){
    	return userRepository.save(user);
    }

    public void deleteUser(Long userId){
    	userRepository.deleteById(userId);
    }

    public void updateUser(Users user){
    	Users existing_user=userRepository.findById(user.getId()).get();
    	if(existing_user!=null) {
    		existing_user.setUsername(user.getUsername());
    		existing_user.setPassword(user.getPassword());
    		userRepository.save(existing_user);
    	}
    }

}

package com.example.todocrud.services;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.todocrud.entity.Todo;
import com.example.todocrud.entity.Users;
import com.example.todocrud.repository.ToDoRepository;
import com.example.todocrud.repository.UserRepository;

@Service
public class TodoServices {

    @Autowired
     UserServices userServices;
    @Autowired
    ToDoRepository toDoRepository;
    @Autowired
     UserRepository userRepository;

    public Todo getTodoById(Long todoId){
        return toDoRepository.findById(todoId).get();
    }

    public void addTodo(Long userId, Todo todo){
        Users user=userRepository.findById(userId).get();
        if(user!=null) {
        List<Todo> TodoList=user.getTodoList();
        	TodoList.add(todo);
        	user.setTodoList(TodoList);
        	userRepository.save(user);
        }
        
    }
    public void deleteTodo(Long userId,Long todoId){
    	Optional<Users> userOptional = userRepository.findById(userId);
        
        if (userOptional.isPresent()) {
            Users user = userOptional.get();
            List<Todo> todoList = user.getTodoList();
            
            for (int i = 0; i < todoList.size(); i++) {
                Todo todo = todoList.get(i);
                if (todo != null && todo.getId()==todoId) {
                    todoList.remove(i);
                    break;
                }
            }
            
            user.setTodoList(todoList);
            userRepository.save(user);
            toDoRepository.deleteById(todoId);
        } else {
            return;
        }
    	
    }

    public void toggleTodoCompleted(Long todoId){
        Todo todo = this.getTodoById(todoId);
        todo.setCompleted(!todo.getCompleted());
        toDoRepository.save(todo);
    }

    public void updateTodo(Todo todo) {
    	Todo existing_todo=toDoRepository.findById(todo.getId()).get();
    	if(existing_todo!=null) {
    		existing_todo.setContent(todo.getContent());
    		existing_todo.setCompleted(todo.getCompleted());
    	}
    }

}

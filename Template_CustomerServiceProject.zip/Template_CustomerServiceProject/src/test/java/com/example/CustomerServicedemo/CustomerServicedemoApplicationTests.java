package com.example.CustomerServicedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerServicedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.devtools.solution.actuator;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id="database")
public class CustomEndpoint1 {
	
	Map<String,String> map=new HashMap<>();
	
	@ReadOperation
	public Map getDbInfo() {
		 map.put("database", "MySQL");
		 return map;
	}

}

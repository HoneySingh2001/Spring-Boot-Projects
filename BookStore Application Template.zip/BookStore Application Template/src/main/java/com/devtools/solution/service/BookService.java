package com.devtools.solution.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devtools.solution.DTO.BookDto;
import com.devtools.solution.entity.Book;
import com.devtools.solution.repo.BookDal;
@Service
public class BookService {

	@Autowired
	BookDal bookDal;
	public Book getBookById(Integer id) {
		return bookDal.findById(id).get();
	}

	public void saveBook(BookDto bookDto) {
		Book book = new Book();
		book.setAuthor(bookDto.getAuthor());
		book.setPrice(bookDto.getPrice());
		book.setQuantity(bookDto.getQuantity());
		book.setTitle(bookDto.getTitle());
		bookDal.save(book);
		
	}

	public void deleteBookById(Integer id) {
		bookDal.deleteById(id);
		
	}

	public List<Book> getAllBooks() {
		return bookDal.findAll();
	}

}

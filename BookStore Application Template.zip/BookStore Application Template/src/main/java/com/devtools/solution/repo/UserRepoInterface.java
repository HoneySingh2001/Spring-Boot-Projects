package com.devtools.solution.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.devtools.solution.entity.User;

@Repository
public  interface UserRepoInterface extends JpaRepository<User,Integer>{

}

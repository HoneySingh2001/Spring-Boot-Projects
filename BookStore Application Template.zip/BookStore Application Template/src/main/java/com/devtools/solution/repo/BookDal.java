package com.devtools.solution.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.devtools.solution.entity.Book;

@Repository
public  interface BookDal extends JpaRepository<Book,Integer>{

}

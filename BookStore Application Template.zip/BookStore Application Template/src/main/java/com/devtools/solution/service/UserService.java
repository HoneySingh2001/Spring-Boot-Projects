package com.devtools.solution.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devtools.solution.entity.User;
import com.devtools.solution.repo.UserRepoInterface;

@Service
public class UserService {

	@Autowired
	UserRepoInterface userRepo;
	
	public User getUserById(Integer id) {
		return userRepo.findById(id).get();
	}

	public void saveUser(User user) {
		userRepo.save(user);
		
	}

	public void deleteUser(Integer id) {
		userRepo.deleteById(id);
		
	}

}

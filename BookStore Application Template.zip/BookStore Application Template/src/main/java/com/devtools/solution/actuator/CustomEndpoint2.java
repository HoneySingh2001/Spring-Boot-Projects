package com.devtools.solution.actuator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

import com.devtools.solution.entity.Book;
import com.devtools.solution.repo.BookDal;

@Component
@Endpoint(id="stock")
public class CustomEndpoint2 {

	@Autowired
	 BookDal bookDal;
	 Map< String, Integer > quantitiesMap = new HashMap<>();
	 
	 @ReadOperation
	public Map getBookQuantities() {
		 List<Book> list=bookDal.findAll();
		 for(Book book:list) {
			 quantitiesMap.put(book.getTitle(), book.getQuantity());
		 }
		 return quantitiesMap;

	}
}

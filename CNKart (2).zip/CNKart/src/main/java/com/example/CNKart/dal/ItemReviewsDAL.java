package com.example.CNKart.dal;

import com.example.CNKart.Entity.ItemReview;

public interface ItemReviewsDAL {

	void save(ItemReview itemReview);

}

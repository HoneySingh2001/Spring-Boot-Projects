package com.example.CNKart.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.CNKart.Entity.ItemReview;
import com.example.CNKart.dal.ItemReviewsDAL;

import jakarta.transaction.Transactional;

@Service
public class ItemReviewsService {

	@Autowired
	ItemReviewsDAL  itemReviewsDAL; 
	@Transactional
	public void save(ItemReview itemReview) {
		itemReviewsDAL.save(itemReview); 
		
	}

}

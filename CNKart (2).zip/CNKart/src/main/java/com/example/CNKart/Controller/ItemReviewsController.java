package com.example.CNKart.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.CNKart.Entity.ItemReview;
import com.example.CNKart.Service.ItemReviewsService;

@RestController
@RequestMapping("/review")
public class ItemReviewsController {

	@Autowired
	ItemReviewsService itemReviewsService;
	
	@PostMapping("/save")
	public void save(@RequestBody ItemReview itemReview) {
		itemReviewsService.save(itemReview);
	}
}

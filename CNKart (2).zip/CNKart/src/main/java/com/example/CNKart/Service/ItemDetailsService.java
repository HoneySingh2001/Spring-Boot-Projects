package com.example.CNKart.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.CNKart.dal.ItemDetailsDAL;

import jakarta.transaction.Transactional;

@Service
public class ItemDetailsService {

	@Autowired
	ItemDetailsDAL itemDetailsDAL;
	
	@Transactional
	public void delete(int id) {
		itemDetailsDAL.delete(id);
		
	}

	

}

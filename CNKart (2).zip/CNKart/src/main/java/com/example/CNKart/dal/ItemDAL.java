package com.example.CNKart.dal;

import com.example.CNKart.Entity.Item;

//import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;

public interface ItemDAL {

	Item getById(int id);

	void addById(Item item);

	void deleteById(int id);

	void updateById(Item updateitem);
}

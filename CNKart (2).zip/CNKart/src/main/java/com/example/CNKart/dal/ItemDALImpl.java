package com.example.CNKart.dal;
import com.example.CNKart.Entity.Item;

import org.hibernate.Session;
//import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class ItemDALImpl implements ItemDAL {

	@Autowired	
	EntityManager entityManager;
	
	
	@Override
	public com.example.CNKart.Entity.Item getById(int id) {
		Session session= entityManager.unwrap(Session.class);
		Item item=session.get(Item.class, id);
		return item;
	}
	@Override
	public void addById(Item item) {
		Session session=entityManager.unwrap(Session.class);
		session.save(item);
		
	}
	@Override
	public void deleteById(int id) {
		Session session=entityManager.unwrap(Session.class);
		Item item=session.get(Item.class, id);
		session.delete(item);
		
	}
	@Override
	public void updateById(Item updateitem) {
		Session session=entityManager.unwrap(Session.class);
		Item curritem=session.get(Item.class, updateitem.getId());
		curritem.setDescription(curritem.getDescription());
		curritem.setName(curritem.getName());
		session.update(curritem);
		
		
	}

}

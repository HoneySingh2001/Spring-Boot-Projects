package com.example.CNKart.dal;

public interface ItemDetailsDAL {

	void delete(int id);

	
}

package com.example.CNKart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CnKartApplication {

	public static void main(String[] args) {
		SpringApplication.run(CnKartApplication.class, args);
	}

}

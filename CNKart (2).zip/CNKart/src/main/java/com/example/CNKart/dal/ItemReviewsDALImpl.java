package com.example.CNKart.dal;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.CNKart.Entity.ItemReview;

import jakarta.persistence.EntityManager;
@Repository
public class ItemReviewsDALImpl implements ItemReviewsDAL {

	
	@Autowired
	EntityManager entityManager;
	@Override
	public void save(ItemReview itemReview) {
		Session session=entityManager.unwrap(Session.class);
		session.save(itemReview);
		
	}

}

package com.example.CNKart.Service;


//import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.CNKart.Entity.Item;
import com.example.CNKart.dal.ItemDAL;

import jakarta.transaction.Transactional;

@Service
public class ItemService {

	@Autowired
	ItemDAL itemDAL;
	
	@Transactional
	public Item getItemById(int id) {
		
		 return itemDAL.getById(id);
	}
	@Transactional
	public void addItemById(Item item) {
		itemDAL.addById(item);
		
	}
	@Transactional
	public void deleteById(int id) {
		itemDAL.deleteById(id);
		
	}
	@Transactional
	public void updateItemById(Item updateitem) {
		itemDAL.updateById(updateitem);
		
	}

	
}

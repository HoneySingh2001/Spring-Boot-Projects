package com.example.CNKart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CnKartApplicationTests {

	@Test
	void contextLoads() {
	}

}

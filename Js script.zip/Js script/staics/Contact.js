document.addEventListener('DOMContentLoaded', () => {
    const commentForm = document.getElementById('contactForm'); // Changed to 'contactForm'
    const commentList = document.createElement('ul'); // Create <ul> for comments
    commentList.id = 'commentList'; // Set id for the <ul>

    // Append the comment list to the DOM
    const commentsSection = document.querySelector('.contact-container');
    commentsSection.appendChild(commentList);

    commentForm.addEventListener('submit', (event) => {
        event.preventDefault();

        // Get form values
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;

        // Create new comment element
        const newComment = document.createElement('li');
        newComment.classList.add('comment-item');
        newComment.innerHTML = `
            <strong>${firstName} ${lastName}</strong> (${email}): ${message}
        `;

        // Add new comment to the comment list
        commentList.appendChild(newComment);

        // Reset form fields after submission
        commentForm.reset();
    });
});

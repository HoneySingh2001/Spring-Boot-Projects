// Get all elements with class 'facility-box'
const facilityElements = document.querySelectorAll(".facility-box");

// Attach click event listener to each facility box
facilityElements.forEach(function(facilityElement) {
    facilityElement.addEventListener('click', function() {
        // Get title and description of clicked facility
        const title = facilityElement.querySelector("h3").textContent;
        const description = facilityElement.querySelector("p").textContent;
        // Call function to display modal with facility details
        showDescription(title, description);
    });
});

// Function to display modal with facility details
function showDescription(title, description) {
    const modal = document.getElementById("facilityModal");
    const titleElement = document.getElementById("facilityTitle");
    const descriptionElement = document.getElementById("facilityDescription");

    // Set title and description in modal
    titleElement.textContent = title;
    descriptionElement.textContent = description;

    // Display modal
    modal.style.display = "block";
}

// Function to close modal
function closeModal() {
    const modal = document.getElementById("facilityModal");
    modal.style.display = "none";
}

// Close modal if user clicks outside of it
window.onclick = function(event) {
    const modal = document.getElementById("facilityModal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
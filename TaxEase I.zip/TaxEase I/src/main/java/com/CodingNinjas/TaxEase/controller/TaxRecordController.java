package com.CodingNinjas.TaxEase.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.CodingNinjas.TaxEase.dto.TaxRecordDto;
import com.CodingNinjas.TaxEase.model.TaxRecord;
import com.CodingNinjas.TaxEase.service.TaxRecordService;

@RestController
@RequestMapping("/api/tax")
public class TaxRecordController {

    @Autowired
    private TaxRecordService taxRecordService;

    @GetMapping("/{id}")
//    @PreAuthorize("hasRole('NORMAL')")
    @ResponseStatus(HttpStatus.OK)
    public TaxRecord getTaxRecordById(@PathVariable Long id){
        return taxRecordService.getTaxRecordById(id);
    }

    @GetMapping("/all")
//    @PreAuthorize("hasRole('NORMAL')")
    @ResponseStatus(HttpStatus.OK)
    public List<TaxRecord> getALlTaxRecords(){
        return taxRecordService.getAllRecords();
    }

    @PostMapping("")
//    @PreAuthorize("hasRole('NORMAL')")
    @ResponseStatus(HttpStatus.OK)
    public void createTaxRecord(@RequestBody TaxRecordDto taxRecordDto){
        taxRecordService.createTaxRecord(taxRecordDto);
    }

    @PutMapping("/{id}")
//    @PreAuthorize("hasRole('NORMAL')")
    @ResponseStatus(HttpStatus.OK)
    public void updateTaxRecord(@RequestBody TaxRecordDto taxRecordDto, @PathVariable Long id){
        taxRecordService.updateTaxRecord(taxRecordDto, id);
    }

    @DeleteMapping("/{id}")
//    @PreAuthorize("hasRole('NORMAL')")
    @ResponseStatus(HttpStatus.OK)
    public void deleteTaxRecord(@PathVariable Long id){
        taxRecordService.deleteTaxRecord(id);
    }

    @GetMapping("")
//    @PreAuthorize("hasRole('NORMAL')")
    @ResponseStatus(HttpStatus.OK)
    public List<TaxRecord> getTaxRecordsByUserName(@RequestParam String userName){
        return taxRecordService.getRecordsByName(userName);
    }

    @PostMapping("/approve/{id}")
//    @PreAuthorize("hasRole('ADMIN')")
    @ResponseStatus(HttpStatus.OK)
    public void approveTaxFiling(@PathVariable Long id){
        taxRecordService.approveTaxFiling(id);
    }

    @PostMapping("/reject/{id}")
//    @PreAuthorize("hasRole('ADMIN')")
    @ResponseStatus(HttpStatus.OK)
    public void rejectTaxFiling(@PathVariable Long id){
        taxRecordService.rejectTaxFiling(id);
    }

}

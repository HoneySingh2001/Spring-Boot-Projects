package com.codingninjas.Foodies.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingninjas.Foodies.Exceptions.ResourceNotFoundException;
import com.codingninjas.Foodies.entity.Customer;
import com.codingninjas.Foodies.entity.Rating;
import com.codingninjas.Foodies.entity.Restaurant;
import com.codingninjas.Foodies.repository.CustomerRepository;
import com.codingninjas.Foodies.repository.RatingRepository;
import com.codingninjas.Foodies.repository.RestaurantRepository;

@Service
public class MainService {

	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	RatingRepository ratingRepository;
	
	@Autowired
	RestaurantRepository restaurantRepository;
	
	public void saveRestaurant(Restaurant restaurant) {
		restaurantRepository.save(restaurant);
	}

	public void saveCustomer(Customer customer) {
		customerRepository.save(customer);
		
	}

	public List<Rating> getAllRating() {
		List<Rating> ratingList= ratingRepository.findAll();
		if(ratingList!=null)
		return ratingList;
		else
			throw new ResourceNotFoundException("No ratings found");
	}

	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}

	public void addRatingForCustomer(Rating rating, Integer customerId, String restaurantName) {
		Customer customer=customerRepository.getById(customerId);
		Restaurant restaurant=restaurantRepository.findByName(restaurantName);
//		if(restaurant!=null) {
//			rating.setRestaurant(restaurant);
//			rating.setCustomer(customer);
//			
//		}
		rating.setRestaurant(restaurant);
		Rating savedRating=ratingRepository.save(rating);
		customer.getRatings().add(savedRating);
		customer.getVisitedRestaurants().add(restaurant);
		customerRepository.save(customer);
		
	}

	public List<Customer> getAllCustomerByRestaurant(String restaurantName) {
		Restaurant restaurant=restaurantRepository.findByName(restaurantName);
		if(restaurant!=null) {
			return customerRepository.findByVisitedRestaurants(restaurant);
		}
		else
			throw new ResourceNotFoundException("No Customer Visited this restaurant");
	}

	public List<Customer> getAllCustomerRatedWell(String restaurantName, double rating) {
		Restaurant restaurant=restaurantRepository.findByName(restaurantName);
		
		return customerRepository.findByVisitedRestaurantAndRatingGreaterThan(restaurantName,rating);
	}

	public double getAverageOfAllRatingsOfRestaurant(String restaurantName) {
		return ratingRepository.findAverageRatingByRestaurantName(restaurantName);
	}

	
	
	

}

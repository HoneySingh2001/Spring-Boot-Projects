package com.springMVC.demo.service;

import com.springMVC.demo.domain.User;

public interface UserService {

	public User getUser();
	public boolean SignUpUser(String name,String gender,String location,String college);
	
}

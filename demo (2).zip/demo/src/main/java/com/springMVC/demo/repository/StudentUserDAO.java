package com.springMVC.demo.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.springMVC.demo.domain.StudentUser;

@Repository
@Scope("singleton")
public class StudentUserDAO implements DAO<StudentUser>{

	List<StudentUser> studentUserList=new ArrayList<>();
	@Override
	public Optional<StudentUser> get(int id) {
		if(!studentUserList.isEmpty()) {
			return Optional.of(studentUserList.get(id));
		}
		return Optional.empty();
	}

	@Override
	public int save(StudentUser student) {
		int userId=studentUserList.size();
		student.setId(userId);
		studentUserList.add(student);
		return userId;
	}

	

	

}

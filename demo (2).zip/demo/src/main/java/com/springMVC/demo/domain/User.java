package com.springMVC.demo.domain;

public interface User {

	public boolean createUser(String name,String gender,String location,String college);
	public int saveUser();
}

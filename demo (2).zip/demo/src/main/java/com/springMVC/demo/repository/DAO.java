package com.springMVC.demo.repository;

import java.util.Optional;

public interface DAO<T> {
 
	public Optional<T> get(int id);
	public int save(T t);
}

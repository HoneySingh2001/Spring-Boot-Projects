package com.springMVC.demo.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springMVC.demo.domain.StudentUser;
import com.springMVC.demo.domain.User;
import com.springMVC.demo.service.UserService;

@Controller
public class signupController {

	@Autowired
	UserService userService;
	@RequestMapping("/signup")
	public String getSignUpPage(Model uiModel) {
		User user=userService.getUser();
		uiModel.addAttribute("user",user);
		return "signup";
	}
	
	@RequestMapping("/registerUser")
	public String getWelcomePage(@ModelAttribute(value="user") StudentUser studentUser) {
		if(userService.SignUpUser(studentUser.getName(), studentUser.getGender(), studentUser.getLocation(), studentUser.getCollege())){
			return "welcome";
		}
		
			return "signup";
		}
	
	
}

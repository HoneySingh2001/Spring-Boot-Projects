package com.cn.homeControlSystem.actuator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.stereotype.Component;

import com.cn.homeControlSystem.model.SmartDevice;
import com.cn.homeControlSystem.repositories.SmartDevicesRepository;

//add required annotations for this custom actuator endpoinr class.
@Component
@Endpoint(id="statusInfo")

public class Actuator { 

    
	@Autowired
	SmartDevicesRepository smartDeviceRepository;

    Map<String, String> data = new HashMap<>();

/**
 * Complete the method body of by writing the necessary logic to fetch a map of all smart devices with their status in a key-value pair.
 * Add required annotation.
 */

    public Map getDeviceStatus() {
    	List<SmartDevice> list=new ArrayList<>();
    	list=smartDeviceRepository.findAll();
    	for(SmartDevice device:list) {
    		data.put(device.getName(), device.getStatus());
    	}
        return data;
    }
}

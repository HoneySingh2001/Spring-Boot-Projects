package com.honey.Registration.Service;

import com.honey.Registration.Entity.User;

public interface UserInterface {

	public void registerUser(User user);
}

package com.honey.Registration.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.honey.Registration.Entity.User;


@Repository
public interface UserRepo extends JpaRepository<User,String>{

}
